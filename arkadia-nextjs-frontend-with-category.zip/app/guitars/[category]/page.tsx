import { products } from "../../data/products";
import { useState } from "react";
import Link from "next/link";

export default function CategoryPage({ params }: { params: { category: string } }) {
  const category = decodeURIComponent(params.category);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, Infinity]);

  const productsInCategory = products.filter(
    (p) => p.category === category && p.price >= priceRange[0] && p.price <= priceRange[1]
  );
  const brands = Array.from(new Set(products.filter((p) => p.category === category).map((p) => p.brand)));
  const toggleBrand = (brand: string) => {
    setSelectedBrands(prev => prev.includes(brand) ? prev.filter(b => b !== brand) : [...prev, brand]);
  };
  const filteredProducts = selectedBrands.length > 0
    ? productsInCategory.filter(p => selectedBrands.includes(p.brand))
    : productsInCategory;

  const prices = products.filter(p => p.category === category).map(p => p.price);
  const minPrice = Math.min(...prices);
  const maxPrice = Math.max(...prices);

  return (
    <div className="px-10 py-16 max-w-7xl mx-auto">
      <h1 className="text-4xl mb-8">{category}</h1>
      <div className="flex gap-10">
        <aside className="w-64 flex-shrink-0">
          <h3 className="text-xl mb-4">Szűrők</h3>
          <div className="mb-6">
            <h4 className="font-semibold mb-2">Márka</h4>
            {brands.map(brand => (
              <label key={brand} className="block mb-1 cursor-pointer">
                <input type="checkbox" className="mr-2" checked={selectedBrands.includes(brand)} onChange={() => toggleBrand(brand)}/>
                {brand}
              </label>
            ))}
          </div>
          <div>
            <h4 className="font-semibold mb-2">Ár</h4>
            <p className="text-gray-400 mb-2">{minPrice} Ft - {maxPrice} Ft</p>
            <div className="flex gap-2">
              <input type="number" placeholder={minPrice.toString()} className="w-24 p-1 rounded bg-[#141414] text-white border border-gray-600" onChange={e => setPriceRange([Number(e.target.value), priceRange[1]])}/>
              <input type="number" placeholder={maxPrice.toString()} className="w-24 p-1 rounded bg-[#141414] text-white border border-gray-600" onChange={e => setPriceRange([priceRange[0], Number(e.target.value)])}/>
            </div>
          </div>
        </aside>
        <section className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-8">
          {filteredProducts.map(product => (
            <Link key={product.id} href={`/guitars/${product.id}`}>
              <div className="bg-[#141414] rounded-xl p-4 cursor-pointer hover:shadow-lg transition">
                <div className="h-48 bg-gray-800 rounded-xl mb-4 overflow-hidden">
                  <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover"/>
                </div>
                <h3 className="text-lg">{product.name}</h3>
                <p className="text-gray-400">{product.brand}</p>
                <p className="text-[#c2a26b]">{product.price} Ft</p>
              </div>
            </Link>
          ))}
        </section>
      </div>
    </div>
  );
}