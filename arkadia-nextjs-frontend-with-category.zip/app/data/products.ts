export type Product = {
  id: string;
  name: string;
  category: string;
  subcategory?: string;
  brand: string;
  price: number;
  images: string[];
};

export const products: Product[] = [
  {
    id: "fender-strat-6",
    name: "Fender Stratocaster 6 húros",
    category: "Elektromos gitárok",
    brand: "Fender",
    price: 420000,
    images: ["/images/fender-strat-6.jpg"],
  },
  {
    id: "gibson-les-paul",
    name: "Gibson Les Paul Standard",
    category: "Elektromos gitárok",
    brand: "Gibson",
    price: 650000,
    images: ["/images/gibson-les-paul.jpg"],
  },
  {
    id: "yamaha-f310",
    name: "Yamaha F310 Akusztikus",
    category: "Akusztikus gitárok",
    brand: "Yamaha",
    price: 75000,
    images: ["/images/yamaha-f310.jpg"],
  },
];